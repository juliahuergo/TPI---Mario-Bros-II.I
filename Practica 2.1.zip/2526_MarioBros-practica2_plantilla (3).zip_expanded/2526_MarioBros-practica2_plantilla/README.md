# Prácticas de TPI del curso 2025-26

- [Enunciado de la Práctica 1](./enunciados/practica1/practica1.md) ([English](./enunciados/practica1/practica1_en.md))
    
    - [Plantilla de la Práctica 1](https://github.com/informaticaucm-TPI/2526_MarioBros/releases/tag/practica1_plantilla)
   
- [Enunciado de la Práctica 2_1](./enunciados/practica2/practica2_1.md) ([English](./enunciados/practica2/practica2_1_en.md))
    
    - [Plantilla de la Práctica 2](https://github.com/informaticaucm-TPI/2526_MarioBros/releases/tag/practica2_plantilla)
